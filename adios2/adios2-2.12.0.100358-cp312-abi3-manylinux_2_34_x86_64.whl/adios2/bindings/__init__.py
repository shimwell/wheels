# SPDX-FileCopyrightText: 2026 Oak Ridge National Laboratory and Contributors
#
# SPDX-License-Identifier: Apache-2.0

from .adios2_bindings import *

__version__ = "2.12.0.100358"
