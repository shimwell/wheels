/*
 * SPDX-FileCopyrightText: 2026 Oak Ridge National Laboratory and Contributors
 *
 * SPDX-License-Identifier: Apache-2.0
 */


#ifndef ADIOS2_BINDINGS_CXX_CXX11_ADIOSVIEW_H_
#define ADIOS2_BINDINGS_CXX_CXX11_ADIOSVIEW_H_

#if defined(_MSC_VER)
#pragma message("DEPRECATED: bindings/CXX/adios2/cxx11 has been renamed to bindings/CXX/adios2/cxx. Please update your includes.")
#else
#warning "DEPRECATED: bindings/CXX/adios2/cxx11 has been renamed to bindings/CXX/adios2/cxx. Please update your includes."
#endif

#include "../cxx/ADIOSView.h"

#endif /* ADIOS2_BINDINGS_CXX_CXX11_ADIOSVIEW_H_ */
