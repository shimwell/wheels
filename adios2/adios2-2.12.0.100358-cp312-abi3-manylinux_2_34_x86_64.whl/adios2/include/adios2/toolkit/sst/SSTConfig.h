/*
 * SPDX-FileCopyrightText: 2026 Oak Ridge National Laboratory and Contributors
 *
 * SPDX-License-Identifier: Apache-2.0
 */


#ifndef SSTCONFIG_H_
#define SSTCONFIG_H_

/* Everything past this line is programatically generated */


/* CMake Option: SST_USE_LIBFABRIC=OFF */
/* #undef SST_HAVE_LIBFABRIC */

/* CMake Option: SST_USE_UCX=OFF */
/* #undef SST_HAVE_UCX */

/* CMake Option: SST_USE_MERCURY=OFF */
/* #undef SST_HAVE_MERCURY */

/* CMake Option: SST_USE_FI_GNI=OFF */
/* #undef SST_HAVE_FI_GNI */

/* CMake Option: SST_USE_CRAY_DRC=OFF */
/* #undef SST_HAVE_CRAY_DRC */

/* CMake Option: SST_USE_CRAY_CXI=OFF */
/* #undef SST_HAVE_CRAY_CXI */

/* CMake Option: SST_USE_NVStream=OFF */
/* #undef SST_HAVE_NVSTREAM */

/* CMake Option: SST_USE_MPI=OFF */
/* #undef SST_HAVE_MPI */

/* CMake Option: SST_USE_MPI_DP_HEURISTICS_PASSED=OFF */
/* #undef SST_HAVE_MPI_DP_HEURISTICS_PASSED */


#endif /* SSTCONFIG_H_ */
