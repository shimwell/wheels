"""Layer for small backward compatibility wrappers for DOLFINx"""

import numpy.typing as npt
import numpy as np
import dolfinx
import inspect

__all__ = [
    "create_partitioner",
    "create_cell_permutations",
    "compute_integration_domains",
    "get_facet_permutations",
    "create_cpp_finite_element",
]


def create_partitioner(
    ghost_mode: dolfinx.mesh.GhostMode = dolfinx.mesh.GhostMode.shared_facet,
    max_facet_to_cell_links: int = 2,
):
    """Create a partitioner across the supported DOLFINx versions.

    The constructor has changed shape more than once and none of the forms is
    introspectable, so they are told apart by the `TypeError` the call itself raises:

    1. communicator and ghost mode only, everything else through setters;
    2. the same with `max_facet_to_cell_links` passed positionally;
    3. as (2) without the communicator.

    Args:
        comm: The communicator of the new partitioner.
        ghost_mode: The ghosting mode to use.
        max_facet_to_cell_links: Maximum number of cells that can share a facet. Used by
            forms (2) and (3) only, which take it directly; form (1) does not accept it.

    Returns:
        The default partitioner
    """
    if not hasattr(dolfinx.mesh, "create_cell_partitioner"):
        partitioner = dolfinx.graph.partitioner()
    else:
        sig = inspect.signature(dolfinx.mesh.create_cell_partitioner)
        part_kwargs = {}
        if "max_facet_to_cell_links" in sig.parameters:
            part_kwargs["max_facet_to_cell_links"] = max_facet_to_cell_links

        partitioner = dolfinx.mesh.create_cell_partitioner(ghost_mode, **part_kwargs)
    return partitioner


def cmap(mesh: dolfinx.mesh.Mesh) -> dolfinx.fem.CoordinateElement:
    """Get the basix Cmap for the mesh."""
    if hasattr(mesh.geometry, "cmaps"):
        return mesh.geometry.cmaps[0]
    if callable(mesh.geometry.cmap):
        return mesh.geometry.cmap()
    else:
        return mesh.geometry.cmap


def dofmap(mesh: dolfinx.mesh.Mesh) -> npt.NDArray[np.int32]:
    """Get the dofmap for the geometry."""
    if hasattr(mesh.geometry, "dofmaps"):
        return mesh.geometry.dofmaps[0]
    if callable(mesh.geometry.dofmap):
        return mesh.geometry.dofmap()
    else:
        return mesh.geometry.dofmap


def form_map(form: dolfinx.fem.Form) -> tuple[dolfinx.common.IndexMap, int]:
    try:
        return (
            form.function_spaces[0].dofmaps(0).index_map,
            form.function_spaces[0].dofmaps(0).index_map_bs,
        )

    except TypeError:
        return (
            form.function_spaces[0].dofmaps[0].index_map,
            form.function_spaces[0].dofmaps[0].index_map_bs,
        )


def index_map(comm, size_local, ghosts, owners, tag: int | None = None):
    if dolfinx.common.IndexMap != dolfinx.cpp.common.IndexMap:
        assert tag is not None, "Tag must be provided for dolfinx.common.index_map"
        return dolfinx.common.index_map(comm, size_local, ghosts=(ghosts, owners), tag=tag)
    else:
        try:
            return dolfinx.common.IndexMap(comm, size_local, ghosts, owners)
        except TypeError:
            assert tag is not None, "Tag must be provided for dolfinx.common.IndexMap"
            return dolfinx.common.IndexMap(comm, size_local, ghosts, owners, tag=tag)


def extract_cpp_object(obj):
    if hasattr(obj, "_cpp_object"):
        return obj._cpp_object
    else:
        return obj


def topology(comm, cell_type, tdim, vertex_map, cell_map, c_to_v, v_to_v, original_cell_index):
    """Construct a ``dolfinx.cpp.mesh.Topology`` across the supported DOLFINx versions.

    The constructor has changed shape more than once and none of the forms is
    introspectable, so they are told apart by the `TypeError` the call itself raises:

    1. communicator and cell type only, everything else through setters;
    2. the same with the maps, dofmap and original cell index passed positionally;
    3. as (2) without the communicator.

    Args:
        comm: The communicator of the new topology.
        cell_type: Its cell type.
        tdim: Its topological dimension, for the index map and connectivity it is set at.
        vertex_map: Index map for dimension 0.
        cell_map: Index map for dimension `tdim`.
        c_to_v: Cell-to-vertex connectivity, in the local numbering of `vertex_map`.
        v_to_v: Vertex-to-vertex connectivity, i.e. the identity over `vertex_map`. Used
            by form (1) only, which cannot derive it.
        original_cell_index: Input global index of each cell. Used by forms (2) and (3),
            which take it directly; form (1) does not accept it.

    Returns:
        The topology, with both index maps and both connectivities set.
    """
    try:
        topology = dolfinx.cpp.mesh.Topology(comm, cell_type)
        topology.set_index_map(0, vertex_map)
        topology.set_index_map(tdim, cell_map)
        topology.set_connectivity(v_to_v, 0, 0)
        topology.set_connectivity(c_to_v, tdim, 0)
        return topology
    except TypeError:
        pass

    args = (
        cell_type,
        extract_cpp_object(vertex_map),
        extract_cpp_object(cell_map),
        extract_cpp_object(c_to_v),
        original_cell_index,
    )
    try:
        return dolfinx.cpp.mesh.Topology(comm, *args)
    except TypeError:
        return dolfinx.cpp.mesh.Topology(*args)


def ghosting_ranks(index_map, tag: int):
    """The ranks that ghost each owned index of `index_map`, flat and with offsets.

    Compat: `IndexMap.index_to_dest_ranks` hands back the two arrays directly in DOLFINx
    0.12 and wraps them in an adjacency list in 0.11.

    Args:
        index_map: The map to read the ghosting ranks of.
        tag: MPI tag for the consensus exchange, the same on every process and not in use
            by another exchange in flight.

    Returns:
        ``(ranks, offsets)``: the ghosting ranks of owned index ``i`` are
        ``ranks[offsets[i]:offsets[i + 1]]``. Collective.
    """
    dest = index_map.index_to_dest_ranks(tag)
    ranks, offsets = (dest.array, dest.offsets) if hasattr(dest, "array") else dest
    return np.asarray(ranks, dtype=np.int32), np.asarray(offsets, dtype=np.int64)


def create_cell_permutations(topology: dolfinx.mesh.Topology):
    """Compute the packed per-cell permutation info, across DOLFINx versions.

    Args:
        topology: The topology to compute the permutation info of.
    """
    if hasattr(topology, "create_cell_permutations"):
        topology.create_cell_permutations()
    else:  # DOLFINx < 0.10, where it takes no dimension
        topology.create_entity_permutations()  # type: ignore[call-arg]


def compute_integration_domains(
    integral_type: dolfinx.fem.IntegralType,
    topology: dolfinx.mesh.Topology,
    entities: npt.NDArray[np.int32],
) -> npt.NDArray[np.int32]:
    """:py:func:`dolfinx.fem.compute_integration_domains` across DOLFINx versions.

    Older versions also take the dimension of ``entities``, which follows from
    ``integral_type``: the cells for a cell integral, the facets otherwise.

    Args:
        integral_type: The type of integral the entities are for.
        topology: The topology of the mesh the entities belong to.
        entities: The entities, local to the process.

    Returns:
        The integration entities, flattened, as returned by DOLFINx.
    """
    try:
        return dolfinx.fem.compute_integration_domains(integral_type, topology, entities)
    except TypeError:
        dim = topology.dim if integral_type == dolfinx.fem.IntegralType.cell else topology.dim - 1
        return dolfinx.fem.compute_integration_domains(integral_type, topology, entities, dim)


def get_facet_permutations(topology: dolfinx.mesh.Topology) -> npt.NDArray[np.uint8]:
    """The permutation of every facet of every cell, across DOLFINx versions.

    Each value encodes how a facet is oriented as seen from a cell, relative to a low-to-high
    ordering of its global vertex indices, as FFCx uses for ``quadrature_permutation``.

    Args:
        topology: The topology to compute the facet permutations of.

    Returns:
        The permutations, shape ``(num_cells, num_facets_per_cell)``, ghost cells included.
    """
    fdim = topology.dim - 1
    num_facets_per_cell = dolfinx.cpp.mesh.cell_num_entities(topology.cell_type, fdim)
    if hasattr(topology, "create_cell_permutations"):
        topology.create_entity_permutations(fdim)
        permutations = topology.get_entity_permutations(fdim)
    else:  # DOLFINx < 0.10
        topology.create_entity_permutations()  # type: ignore[call-arg]
        permutations = topology.get_facet_permutations()
    return np.asarray(permutations).reshape(-1, num_facets_per_cell)


def create_cpp_finite_element(constructor, element, gdim: int, block_shape: tuple[int, ...]):
    """Create a blocked C++ finite element across the supported DOLFINx versions.

    FEniCS/dolfinx#4511 added the geometric dimension to the constructor. Versions from before
    ``block_shape`` existed raise ``TypeError``, for the caller to fall back on ``block_size``.

    Args:
        constructor: ``dolfinx.cpp.fem.FiniteElement_float32`` or ``_float64``.
        element: The C++ Basix element.
        gdim: Geometric dimension of the mesh.
        block_shape: Block shape of the element.
    """
    try:
        return constructor(element, gdim=gdim, block_shape=block_shape, symmetric=False)
    except TypeError:
        return constructor(element, block_shape=block_shape, symmetric=False)
