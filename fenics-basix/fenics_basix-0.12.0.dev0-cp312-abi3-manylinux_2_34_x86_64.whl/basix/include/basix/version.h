// Copyright (c) 2020 Chris Richardson
// FEniCS Project
// SPDX-License-Identifier:    MIT

#pragma once

#define BASIX_VERSION 0.12.0.0
#define BASIX_VERSION_MAJOR 0
#define BASIX_VERSION_MINOR 12
#define BASIX_VERSION_PATCH 0
