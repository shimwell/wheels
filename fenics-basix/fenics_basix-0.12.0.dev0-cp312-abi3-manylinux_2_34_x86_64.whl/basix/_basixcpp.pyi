"""Interface to the Basix C++ library."""

from collections.abc import Sequence
import enum
from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


def topology(celltype: CellType) -> list[list[list[int]]]: ...

def geometry(celltype: CellType) -> NDArray[numpy.float64]: ...

def sub_entity_type(celltype: CellType, dim: int, index: int) -> CellType: ...

def sub_entity_connectivity(celltype: CellType) -> list[list[list[list[int]]]]: ...

def sub_entity_geometry(celltype: CellType, dim: int, index: int) -> NDArray[numpy.float64]: ...

def subentity_types(celltype: CellType) -> list[list[CellType]]: ...

def sobolev_space_intersection(space1: SobolevSpace, space2: SobolevSpace) -> SobolevSpace: ...

class LatticeType(enum.IntEnum):
    """Lattice type."""

    equispaced = 0

    gll = 1

    chebyshev = 2

    gl = 4

class LatticeSimplexMethod(enum.IntEnum):
    """Lattice simplex method."""

    none = 0

    warp = 1

    isaac = 2

    centroid = 3

class PolynomialType(enum.IntEnum):
    """Polynomial type."""

    legendre = 0

    lagrange = 1

    bernstein = 2

def tabulate_polynomials(ptype: PolynomialType, celltype: CellType, degree: int, pts: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C', writable=False)]) -> NDArray[numpy.float64]: ...

def polynomials_dim(ptype: PolynomialType, celltype: CellType, degree: int) -> int: ...

def create_lattice(celltype: CellType, n: int, ltype: LatticeType, exterior: bool, method: LatticeSimplexMethod) -> NDArray[numpy.float64]: ...

class MapType(enum.IntEnum):
    """Element map type."""

    identity = 0

    L2Piola = 1

    covariantPiola = 2

    contravariantPiola = 3

    doubleCovariantPiola = 4

    doubleContravariantPiola = 5

class SobolevSpace(enum.IntEnum):
    """Sobolev space."""

    L2 = 0

    H1 = 1

    H2 = 2

    H3 = 3

    HInf = 8

    HDiv = 10

    HCurl = 11

    HEin = 12

    HDivDiv = 13

class QuadratureType(enum.IntEnum):
    """Quadrature type."""

    default = 0

    gauss_jacobi = 1

    gll = 2

    xiao_gimbutas = 3

class CellType(enum.IntEnum):
    """Cell type."""

    point = 0

    interval = 1

    triangle = 2

    tetrahedron = 3

    quadrilateral = 4

    hexahedron = 5

    prism = 6

    pyramid = 7

def cell_volume(celltype: CellType) -> float: ...

def cell_facet_normals(celltype: CellType) -> NDArray[numpy.float64]: ...

def cell_facet_reference_volumes(celltype: CellType) -> NDArray[numpy.float64]: ...

def cell_facet_outward_normals(celltype: CellType) -> NDArray[numpy.float64]: ...

def cell_facet_orientations(celltype: CellType) -> list[int]: ...

def cell_facet_jacobians(celltype: CellType) -> NDArray[numpy.float64]: ...

def cell_edge_jacobians(celltype: CellType) -> NDArray[numpy.float64]: ...

class ElementFamily(enum.IntEnum):
    """Finite element family."""

    custom = 0

    P = 1

    BDM = 4

    RT = 2

    N1E = 3

    N2E = 5

    Regge = 7

    HHJ = 11

    bubble = 9

    serendipity = 10

    DPC = 8

    CR = 6

    Hermite = 12

    iso = 13

class LagrangeVariant(enum.IntEnum):
    """Lagrange element variant."""

    unset = 0

    equispaced = 1

    gll_warped = 2

    gll_isaac = 3

    gll_centroid = 4

    chebyshev_warped = 5

    chebyshev_isaac = 6

    chebyshev_centroid = 7

    gl_warped = 8

    gl_isaac = 9

    gl_centroid = 10

    legendre = 11

    bernstein = 12

class DPCVariant(enum.IntEnum):
    """DPC variant."""

    unset = 0

    simplex_equispaced = 1

    simplex_gll = 2

    horizontal_equispaced = 3

    horizontal_gll = 4

    diagonal_equispaced = 5

    diagonal_gll = 6

    legendre = 7

def create_element(family: ElementFamily, celltype: CellType, degree: int, lagrange_variant: LagrangeVariant, dpc_variant: DPCVariant, discontinuous: bool, dof_ordering: Sequence[int], dtype: str) -> FiniteElement_float32 | FiniteElement_float64: ...

def create_tp_element(family: ElementFamily, celltype: CellType, degree: int, lagrange_variant: LagrangeVariant, dpc_variant: DPCVariant, discontinuous: bool, dtype: str) -> FiniteElement_float32 | FiniteElement_float64: ...

def tp_factors(family: ElementFamily, celltype: CellType, degree: int, lagrange_variant: LagrangeVariant, dpc_variant: DPCVariant, discontinuous: bool, dof_ordering: Sequence[int], dtype: str) -> list[list[FiniteElement_float32]] | list[list[FiniteElement_float64]] | None: ...

def tp_dof_ordering(family: ElementFamily, celltype: CellType, degree: int, lagrange_variant: LagrangeVariant, dpc_variant: DPCVariant, discontinuous: bool) -> list[int] | None: ...

def lex_dof_ordering(family: ElementFamily, celltype: CellType, degree: int, lagrange_variant: LagrangeVariant, dpc_variant: DPCVariant, discontinuous: bool) -> list[int]: ...

class PolysetType(enum.IntEnum):
    """Polyset type."""

    standard = 0

    macroedge = 1

def superset(cell: CellType, type1: PolysetType, type2: PolysetType) -> PolysetType: ...

def restriction(ptype: PolysetType, cell: CellType, restriction_cell: CellType) -> PolysetType: ...

def make_quadrature(rule: QuadratureType, cell: CellType, polyset_type: PolysetType, degree: int) -> tuple[NDArray[numpy.float64], NDArray[numpy.float64]]: ...

def gauss_jacobi_rule(alpha: float, npoints: int) -> tuple[NDArray[numpy.float64], NDArray[numpy.float64]]: ...

@overload
def index(p: int) -> int: ...

@overload
def index(p: int, q: int) -> int: ...

@overload
def index(p: int, q: int, r: int) -> int: ...

class FiniteElement_float32:
    def tabulate(self, n: int, x: Annotated[NDArray[numpy.float32], dict(shape=(None, None), order='C', writable=False)]) -> NDArray[numpy.float32]: ...

    def __eq__(self, arg: object, /) -> bool: ...

    def hash(self) -> int: ...

    @overload
    def permute_subentity_closure(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], entity_info: int, entity_type: CellType) -> None: ...

    @overload
    def permute_subentity_closure(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], cell_info: int, entity_type: CellType, entity_index: int) -> None: ...

    @overload
    def permute_subentity_closure_inv(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], entity_info: int, entity_type: CellType) -> None: ...

    @overload
    def permute_subentity_closure_inv(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], cell_info: int, entity_type: CellType, entity_index: int) -> None: ...

    def push_forward(self, U: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', writable=False)], J: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', writable=False)], detJ: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C', writable=False)], K: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', writable=False)]) -> NDArray[numpy.float32]: ...

    def pull_back(self, u: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', writable=False)], J: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', writable=False)], detJ: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C', writable=False)], K: Annotated[NDArray[numpy.float32], dict(shape=(None, None, None), order='C', writable=False)]) -> NDArray[numpy.float32]: ...

    def T_apply(self, u: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], n: int, cell_info: int) -> None: ...

    def Tt_apply_right(self, u: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], n: int, cell_info: int) -> None: ...

    def Tt_inv_apply(self, u: Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], n: int, cell_info: int) -> None: ...

    def base_transformations(self) -> NDArray[numpy.float32]: ...

    def entity_transformations(self) -> dict: ...

    def get_tensor_product_representation(self) -> list[list[FiniteElement_float32]]: ...

    @property
    def degree(self) -> int: ...

    @property
    def embedded_superdegree(self) -> int: ...

    @property
    def embedded_subdegree(self) -> int: ...

    @property
    def cell_type(self) -> CellType: ...

    @property
    def polyset_type(self) -> PolysetType: ...

    @property
    def dim(self) -> int: ...

    @property
    def num_entity_dofs(self) -> list[list[int]]: ...

    @property
    def entity_dofs(self) -> list[list[list[int]]]: ...

    @property
    def num_entity_closure_dofs(self) -> list[list[int]]: ...

    @property
    def entity_closure_dofs(self) -> list[list[list[int]]]: ...

    @property
    def value_size(self) -> int: ...

    @property
    def value_shape(self) -> list[int]: ...

    @property
    def discontinuous(self) -> bool: ...

    @property
    def family(self) -> ElementFamily: ...

    @property
    def lagrange_variant(self) -> LagrangeVariant: ...

    @property
    def dpc_variant(self) -> DPCVariant: ...

    @property
    def dof_transformations_are_permutations(self) -> bool: ...

    @property
    def dof_transformations_are_identity(self) -> bool: ...

    @property
    def interpolation_is_identity(self) -> bool: ...

    @property
    def map_type(self) -> MapType: ...

    @property
    def sobolev_space(self) -> SobolevSpace: ...

    @property
    def points(self) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None), writable=False)]: ...

    @property
    def interpolation_matrix(self) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None), writable=False)]: ...

    @property
    def dual_matrix(self) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None), writable=False)]: ...

    @property
    def coefficient_matrix(self) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None), writable=False)]:
        """Coefficient matrix."""

    @property
    def wcoeffs(self) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None), writable=False)]: ...

    @property
    def M(self) -> list[list[Annotated[NDArray[numpy.float32], dict(writable=False)]]]: ...

    @property
    def x(self) -> list[list[Annotated[NDArray[numpy.float32], dict(writable=False)]]]: ...

    @property
    def has_tensor_product_factorisation(self) -> bool: ...

    @property
    def interpolation_nderivs(self) -> int: ...

    @property
    def dof_ordering(self) -> list[int]: ...

    @property
    def dtype(self) -> str: ...

def create_custom_element_float32(cell_type: CellType, value_shape: Sequence[int], wcoeffs: Annotated[NDArray[numpy.float32], dict(shape=(None, None), order='C', writable=False)], x: Sequence[Sequence[Annotated[NDArray[numpy.float32], dict(shape=(None, None), order='C', writable=False)]]], M: Sequence[Sequence[Annotated[NDArray[numpy.float32], dict(shape=(None, None, None, None), order='C', writable=False)]]], interpolation_nderivs: int, map_type: MapType, sobolev_space: SobolevSpace, discontinuous: bool, embedded_subdegree: int, embedded_superdegree: int, poly_type: PolysetType) -> FiniteElement_float32: ...

@overload
def compute_interpolation_operator(e0: FiniteElement_float32, e1: FiniteElement_float32) -> NDArray[numpy.float32]: ...

@overload
def compute_interpolation_operator(e0: FiniteElement_float64, e1: FiniteElement_float64) -> NDArray[numpy.float64]: ...

def tabulate_polynomial_set_float32(celltype: CellType, ptype: PolysetType, degree: int, nderiv: int, pts: Annotated[NDArray[numpy.float32], dict(shape=(None, None), order='C', writable=False)]) -> NDArray[numpy.float32]: ...

class FiniteElement_float64:
    def tabulate(self, n: int, x: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C', writable=False)]) -> NDArray[numpy.float64]: ...

    def __eq__(self, arg: object, /) -> bool: ...

    def hash(self) -> int: ...

    @overload
    def permute_subentity_closure(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], entity_info: int, entity_type: CellType) -> None: ...

    @overload
    def permute_subentity_closure(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], cell_info: int, entity_type: CellType, entity_index: int) -> None: ...

    @overload
    def permute_subentity_closure_inv(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], entity_info: int, entity_type: CellType) -> None: ...

    @overload
    def permute_subentity_closure_inv(self, d: Annotated[NDArray[numpy.int32], dict(shape=(None,), order='C')], cell_info: int, entity_type: CellType, entity_index: int) -> None: ...

    def push_forward(self, U: Annotated[NDArray[numpy.float64], dict(shape=(None, None, None), order='C', writable=False)], J: Annotated[NDArray[numpy.float64], dict(shape=(None, None, None), order='C', writable=False)], detJ: Annotated[NDArray[numpy.float64], dict(shape=(None,), order='C', writable=False)], K: Annotated[NDArray[numpy.float64], dict(shape=(None, None, None), order='C', writable=False)]) -> NDArray[numpy.float64]: ...

    def pull_back(self, u: Annotated[NDArray[numpy.float64], dict(shape=(None, None, None), order='C', writable=False)], J: Annotated[NDArray[numpy.float64], dict(shape=(None, None, None), order='C', writable=False)], detJ: Annotated[NDArray[numpy.float64], dict(shape=(None,), order='C', writable=False)], K: Annotated[NDArray[numpy.float64], dict(shape=(None, None, None), order='C', writable=False)]) -> NDArray[numpy.float64]: ...

    def T_apply(self, u: Annotated[NDArray[numpy.float64], dict(shape=(None,), order='C')], n: int, cell_info: int) -> None: ...

    def Tt_apply_right(self, u: Annotated[NDArray[numpy.float64], dict(shape=(None,), order='C')], n: int, cell_info: int) -> None: ...

    def Tt_inv_apply(self, u: Annotated[NDArray[numpy.float64], dict(shape=(None,), order='C')], n: int, cell_info: int) -> None: ...

    def base_transformations(self) -> NDArray[numpy.float64]: ...

    def entity_transformations(self) -> dict: ...

    def get_tensor_product_representation(self) -> list[list[FiniteElement_float64]]: ...

    @property
    def degree(self) -> int: ...

    @property
    def embedded_superdegree(self) -> int: ...

    @property
    def embedded_subdegree(self) -> int: ...

    @property
    def cell_type(self) -> CellType: ...

    @property
    def polyset_type(self) -> PolysetType: ...

    @property
    def dim(self) -> int: ...

    @property
    def num_entity_dofs(self) -> list[list[int]]: ...

    @property
    def entity_dofs(self) -> list[list[list[int]]]: ...

    @property
    def num_entity_closure_dofs(self) -> list[list[int]]: ...

    @property
    def entity_closure_dofs(self) -> list[list[list[int]]]: ...

    @property
    def value_size(self) -> int: ...

    @property
    def value_shape(self) -> list[int]: ...

    @property
    def discontinuous(self) -> bool: ...

    @property
    def family(self) -> ElementFamily: ...

    @property
    def lagrange_variant(self) -> LagrangeVariant: ...

    @property
    def dpc_variant(self) -> DPCVariant: ...

    @property
    def dof_transformations_are_permutations(self) -> bool: ...

    @property
    def dof_transformations_are_identity(self) -> bool: ...

    @property
    def interpolation_is_identity(self) -> bool: ...

    @property
    def map_type(self) -> MapType: ...

    @property
    def sobolev_space(self) -> SobolevSpace: ...

    @property
    def points(self) -> Annotated[NDArray[numpy.float64], dict(shape=(None, None), writable=False)]: ...

    @property
    def interpolation_matrix(self) -> Annotated[NDArray[numpy.float64], dict(shape=(None, None), writable=False)]: ...

    @property
    def dual_matrix(self) -> Annotated[NDArray[numpy.float64], dict(shape=(None, None), writable=False)]: ...

    @property
    def coefficient_matrix(self) -> Annotated[NDArray[numpy.float64], dict(shape=(None, None), writable=False)]:
        """Coefficient matrix."""

    @property
    def wcoeffs(self) -> Annotated[NDArray[numpy.float64], dict(shape=(None, None), writable=False)]: ...

    @property
    def M(self) -> list[list[Annotated[NDArray[numpy.float64], dict(writable=False)]]]: ...

    @property
    def x(self) -> list[list[Annotated[NDArray[numpy.float64], dict(writable=False)]]]: ...

    @property
    def has_tensor_product_factorisation(self) -> bool: ...

    @property
    def interpolation_nderivs(self) -> int: ...

    @property
    def dof_ordering(self) -> list[int]: ...

    @property
    def dtype(self) -> str: ...

def create_custom_element_float64(cell_type: CellType, value_shape: Sequence[int], wcoeffs: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C', writable=False)], x: Sequence[Sequence[Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C', writable=False)]]], M: Sequence[Sequence[Annotated[NDArray[numpy.float64], dict(shape=(None, None, None, None), order='C', writable=False)]]], interpolation_nderivs: int, map_type: MapType, sobolev_space: SobolevSpace, discontinuous: bool, embedded_subdegree: int, embedded_superdegree: int, poly_type: PolysetType) -> FiniteElement_float64: ...

def tabulate_polynomial_set_float64(celltype: CellType, ptype: PolysetType, degree: int, nderiv: int, pts: Annotated[NDArray[numpy.float64], dict(shape=(None, None), order='C', writable=False)]) -> NDArray[numpy.float64]: ...
