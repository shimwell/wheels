{
  "components" : 
  {
    "basix" : 
    {
      "location" : "@prefix@/basix/lib/libbasix.so.0.12.0.0"
    }
  },
  "configuration" : "Release",
  "name" : "Basix"
}