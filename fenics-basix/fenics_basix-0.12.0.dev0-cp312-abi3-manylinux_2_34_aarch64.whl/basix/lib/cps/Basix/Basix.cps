{
  "components" : 
  {
    "basix" : 
    {
      "compile_features" : [ "c++20" ],
      "definitions" : 
      {
        "*" : 
        {
          "MDSPAN_USE_BRACKET_OPERATOR" : "0",
          "MDSPAN_USE_PAREN_OPERATOR" : "1"
        }
      },
      "includes" : [ "@prefix@/basix/include" ],
      "type" : "dylib"
    }
  },
  "configurations" : [ "Release" ],
  "cps_path" : "@prefix@/basix/lib/cps/Basix",
  "cps_version" : "0.14.1",
  "default_components" : [ "basix" ],
  "description" : "Finite element definition and tabulation runtime library",
  "license" : "MIT",
  "name" : "Basix",
  "version" : "0.12.0.0",
  "website" : "https://fenicsproject.org"
}