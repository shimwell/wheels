"""UFL core."""
