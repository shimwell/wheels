"""Intermediate representation."""
