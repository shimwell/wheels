
#ifndef MOAB_EXPORT_H
#define MOAB_EXPORT_H

#ifdef MOAB_STATIC_DEFINE
#  define MOAB_EXPORT
#  define MOAB_NO_EXPORT
#else
#  ifndef MOAB_EXPORT
#    ifdef MOAB_EXPORTS
        /* We are building this library */
#      define MOAB_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MOAB_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MOAB_NO_EXPORT
#    define MOAB_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MOAB_DEPRECATED
#  define MOAB_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MOAB_DEPRECATED_EXPORT
#  define MOAB_DEPRECATED_EXPORT MOAB_EXPORT MOAB_DEPRECATED
#endif

#ifndef MOAB_DEPRECATED_NO_EXPORT
#  define MOAB_DEPRECATED_NO_EXPORT MOAB_NO_EXPORT MOAB_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MOAB_NO_DEPRECATED
#    define MOAB_NO_DEPRECATED
#  endif
#endif

#endif /* MOAB_EXPORT_H */
