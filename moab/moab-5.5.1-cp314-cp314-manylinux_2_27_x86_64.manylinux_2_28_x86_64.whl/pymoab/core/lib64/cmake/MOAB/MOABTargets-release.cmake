#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MOAB" for configuration "Release"
set_property(TARGET MOAB APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MOAB PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/core/lib64/libMOAB.so"
  IMPORTED_SONAME_RELEASE "libMOAB.so"
  )

list(APPEND _cmake_import_check_targets MOAB )
list(APPEND _cmake_import_check_files_for_MOAB "${_IMPORT_PREFIX}/core/lib64/libMOAB.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
