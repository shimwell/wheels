#ifndef MOAB_ENTITY_TYPE_NS_ONLY
#define MOAB_ENTITY_TYPE_NS_ONLY
#include "MBEntityType.h"
#undef MOAB_ENTITY_TYPE_NS_ONLY
#endif
