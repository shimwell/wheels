# Config file for MOAB; use the CMake find_package() function to pull this into
# your own CMakeLists.txt file.
#
# This file defines the following variables:
# MOAB_FOUND        - boolean indicating that MOAB is found
# MOAB_VERSION      - version of MOAB
# MOAB_INCLUDE_DIRS - include directories from which to pick up MOAB includes
# MOAB_LIBRARIES    - libraries need to link to MOAB; use this in target_link_libraries for MOAB-dependent targets
# MOAB_CXX, MOAB_CC, MOAB_F77, MOAB_FC - compilers used to compile MOAB
# MOAB_CXXFLAGS, MOAB_CCFLAGS, MOAB_FFLAGS, MOAB_FCFLAGS - compiler flags used to compile MOAB; possibly need to use these in add_definitions or CMAKE_<LANG>_FLAGS_<MODE> 

set(MOAB_VERSION 5.5.1)

set(MOAB_CC "/opt/rh/gcc-toolset-14/root/usr/bin/gcc")
set(MOAB_CXX "/opt/rh/gcc-toolset-14/root/usr/bin/g++")
set(MOAB_FC "/opt/rh/gcc-toolset-14/root/usr/bin/gfortran")
set(MOAB_F77 "/opt/rh/gcc-toolset-14/root/usr/bin/gfortran")
# Compiler flags used by MOAB
set(MOAB_CFLAGS "-O2 -DNDEBUG -O3 -DNDEBUG -fPIC -DPIC -pedantic -fpic -Wall -pipe -Wno-long-long -Wextra -Wno-cast-align -Wsign-compare -Wpointer-arith -Wformat -Wformat-security -Wunused-parameter -fstack-protector-all -fpermissive -Wno-ignored-attributes -Wno-variadic-macros -Wno-deprecated-declarations -Wno-unused-local-typedefs -O2 -funroll-loops -funroll-all-loops -fstrict-aliasing -Wno-unused ")
set(MOAB_CXXFLAGS "-O2 -DNDEBUG -O3 -DNDEBUG -fPIC -DPIC -pedantic -fpic -Wall -pipe -Wno-long-long -Wextra -Wno-cast-align -Wsign-compare -Wpointer-arith -Wformat -Wformat-security -Wunused-parameter -fstack-protector-all -fpermissive -Wno-ignored-attributes -Wno-variadic-macros -Wno-deprecated-declarations -Wno-unused-local-typedefs -O2 -funroll-loops -funroll-all-loops -fstrict-aliasing -Wno-unused ")
set(MOAB_FCFLAGS "-funroll-all-loops -fno-f2c")
set(MOAB_FFLAGS "-funroll-all-loops -fno-f2c")

set(MOAB_BUILT_SHARED ON)
set(MOAB_USE_MPI OFF)
set(MPI_DIR "")
set(MOAB_USE_HDF5 ON)
set(MOAB_USE_HDF5_PARALLEL OFF)
set(HDF5_DIR "")
set(MOAB_USE_ZLIB OFF)
set(ZLIB_DIR "")
set(MOAB_USE_SZIP OFF)
set(SZIP_DIR "")
set(MOAB_USE_NETCDF OFF)
set(NETCDF_DIR "")
set(MOAB_USE_PNETCDF OFF)
set(PNETCDF_DIR "")
set(MOAB_USE_METIS OFF)
set(METIS_DIR "")
set(MOAB_USE_PARMETIS OFF)
set(PARMETIS_DIR "")
set(MOAB_USE_ZOLTAN OFF)
set(ZOLTAN_DIR "")
set(MOAB_USE_BLAS ON)
set(BLAS_LIBRARIES "/usr/lib64/libblas.so")
set(MOAB_USE_LAPACK ON)
set(LAPACK_LIBRARIES "/usr/lib64/liblapack.so;/usr/lib64/libblas.so")
set(MOAB_USE_EIGEN OFF)
set(EIGEN3_DIR "")
set(TEMPESTREMAP_DIR "")
set(MOAB_USE_TEMPESTREMAP )
set(MOAB_USE_SKBUILD 2)
set(MOAB_MESH_DIR "/project/moab/MeshFiles/unittest")

# Library and include defs
get_filename_component(MOAB_CMAKE_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)

include (${MOAB_CMAKE_DIR}/ResolveCompilerPaths.cmake)

# missing support for DAMSEL, CCMIO
set (MOAB_PACKAGE_LIBS "     /usr/lib64/libhdf5.so   /usr/lib64/liblapack.so;/usr/lib64/libblas.so /usr/lib64/libblas.so " )
string(STRIP "${MOAB_PACKAGE_LIBS}" MOAB_PACKAGE_LIBS)
set(MOAB_PACKAGE_LIBS_LIST ${MOAB_PACKAGE_LIBS})
separate_arguments(MOAB_PACKAGE_LIBS_LIST)
list(REMOVE_DUPLICATES MOAB_PACKAGE_LIBS_LIST)
set(MOAB_PACKAGE_LIBS "${MOAB_PACKAGE_LIBS_LIST}")

set (MOAB_PACKAGE_INCLUDES_LIST "       " )
string(STRIP "${MOAB_PACKAGE_INCLUDES_LIST}" MOAB_PACKAGE_INCLUDES_LIST)
RESOLVE_INCLUDES(MOAB_PACKAGE_INCLUDES "${MOAB_PACKAGE_INCLUDES_LIST}")
separate_arguments(MOAB_PACKAGE_INCLUDES)
list(REMOVE_DUPLICATES MOAB_PACKAGE_INCLUDES)

# Target information
if(MOAB_USE_HDF5)
  if(EXISTS "/share/cmake/hdf5/hdf5-config.cmake")
    include(/share/cmake/hdf5/hdf5-config.cmake)
  endif()
endif()

if(MOAB_USE_SKBUILD)
  # Find the Python interpreter and ensure it's available.
  find_package(Python COMPONENTS Interpreter REQUIRED)

  # Function to run Python commands and validate their execution.
  function(run_python_command output_var command)
    execute_process(
      COMMAND ${Python_EXECUTABLE} -c "${command}"
      OUTPUT_VARIABLE ${output_var}
      OUTPUT_STRIP_TRAILING_WHITESPACE
      RESULT_VARIABLE result
      )
    # Check if the command was successful
    if(NOT result EQUAL 0)
      message(FATAL_ERROR "Failed to run Python command: ${command}")
    else()
      # Add the output variable to the parent scope
      set(${output_var} "${${output_var}}" PARENT_SCOPE)
    endif()
  endfunction()

  # Extract MOAB include paths, library paths, and extra libraries
  run_python_command(MOAB_INCLUDE_DIRS "import pymoab; print(pymoab.include_path[0])")
  run_python_command(MOAB_LIBRARY_DIRS "import pymoab; print(pymoab.lib_path[0])")
  run_python_command(MOAB_EXTRA_LIBRARIES "import pymoab; print(' '.join(pymoab.extra_lib))")

  # Check if the wheel was repaired using auditwheel or delocate
  if(MOAB_EXTRA_LIBRARIES)
    message(FATAL_ERROR
        "This build of MOAB is not supported. "
        "It appears that the wheel was repaired using tools like auditwheel or delocate, "
        "that modifies the shared libraries, which may cause problems.\n"
        "MOAB_EXTRA_LIBRARIES is not empty: ${MOAB_EXTRA_LIBRARIES}.\n"
        "To resolve this, please build MOAB from scratch. "
        "For more information, visit: https://bitbucket.org/fathomteam/moab\n"
      )
  endif()

  # Add MOAB targets
  file(TO_CMAKE_PATH "${MOAB_LIBRARY_DIRS}/cmake/MOAB/MOABTargets.cmake" MOAB_TARGETS_FILE)
  include(${MOAB_TARGETS_FILE})

  # Add the core library to the list of libraries
  set(MOAB_INCLUDE_DIRS ${MOAB_INCLUDE_DIRS} ${MOAB_PACKAGE_INCLUDES})
  set(MOAB_LIBRARIES MOAB ${MOAB_PACKAGE_LIBS})
else()
  if(NOT TARGET MOAB AND NOT MOAB_BINARY_DIR)
    include("${MOAB_CMAKE_DIR}/MOABTargets.cmake")
  endif()
  set(MOAB_LIBRARY_DIRS "/tmp/tmpbfgjkkrz/wheel/platlib/pymoab/lib64")
  set(MOAB_INCLUDE_DIRS "/tmp/tmpbfgjkkrz/wheel/platlib/pymoab/include" ${MOAB_PACKAGE_INCLUDES})
  set(MOAB_LIBS "-lMOAB")
  set(MOAB_LIBRARIES "-L/tmp/tmpbfgjkkrz/wheel/platlib/pymoab/lib64 ${MOAB_LIBS} ${MOAB_PACKAGE_LIBS}")
endif()

# Include standard argument handling for finding packages
include(FindPackageHandleStandardArgs)

# Validates that the necessary variables are set
find_package_handle_standard_args(MOAB
  REQUIRED_VARS MOAB_LIBRARIES MOAB_INCLUDE_DIRS
  VERSION_VAR MOAB_VERSION
  )
