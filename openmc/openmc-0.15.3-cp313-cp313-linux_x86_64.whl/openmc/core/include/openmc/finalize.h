#ifndef OPENMC_FINALIZE_H
#define OPENMC_FINALIZE_H

namespace openmc {} // namespace openmc

#endif // OPENMC_FINALIZE_H
