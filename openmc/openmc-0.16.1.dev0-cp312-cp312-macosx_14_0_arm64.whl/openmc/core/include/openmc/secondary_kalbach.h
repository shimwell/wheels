//! \file secondary_kalbach.h
//! Kalbach-Mann angle-energy distribution

#ifndef OPENMC_SECONDARY_KALBACH_H
#define OPENMC_SECONDARY_KALBACH_H

#include "hdf5.h"
#include "openmc/tensor.h"

#include "openmc/angle_energy.h"
#include "openmc/constants.h"
#include "openmc/endf.h"
#include "openmc/vector.h"

namespace openmc {

//==============================================================================
//! Correlated angle-energy distribution with the angular distribution
//! represented using Kalbach-Mann systematics. This corresponds to ACE law 44
//! and ENDF File 6, LAW=1, LANG=2.
//==============================================================================

class KalbachMann : public AngleEnergy {
public:
  explicit KalbachMann(hid_t group);

  //! Sample distribution for an angle and energy
  //! \param[in] E_in Incoming energy in [eV]
  //! \param[out] E_out Outgoing energy in [eV]
  //! \param[out] mu Outgoing cosine with respect to current direction
  //! \param[inout] seed Pseudorandom seed pointer
  void sample(
    double E_in, double& E_out, double& mu, uint64_t* seed) const override;

  //! Sample outgoing energy and Kalbach-Mann parameters
  //! \param[in] E_in Incoming energy in [eV]
  //! \param[out] E_out Outgoing energy in [eV]
  //! \param[out] km_a Kalbach-Mann 'a' parameter
  //! \param[out] km_r Kalbach-Mann pre-compound fraction 'r'
  //! \param[inout] seed Pseudorandom seed pointer
  void sample_params(double E_in, double& E_out, double& km_a, double& km_r,
    uint64_t* seed) const;

  //! Sample an outgoing energy and evaluate the angular PDF
  //! \param[in] E_in Incoming energy in [eV]
  //! \param[in] mu Scattering cosine with respect to current direction
  //! \param[out] E_out Outgoing energy in [eV]
  //! \param[inout] seed Pseudorandom seed pointer
  //! \return Probability density for the scattering cosine
  double sample_energy_and_pdf(
    double E_in, double mu, double& E_out, uint64_t* seed) const override;

private:
  //! Outgoing energy/angle at a single incoming energy
  struct KMTable {
    int n_discrete;               //!< Number of discrete lines
    Interpolation interpolation;  //!< Interpolation law
    tensor::Tensor<double> e_out; //!< Outgoing energies [eV]
    tensor::Tensor<double> p;     //!< Probability density
    tensor::Tensor<double> c;     //!< Cumulative distribution
    tensor::Tensor<double> r;     //!< Pre-compound fraction
    tensor::Tensor<double> a;     //!< Parameterized function
  };

  int n_region_;                        //!< Number of interpolation regions
  vector<int> breakpoints_;             //!< Breakpoints between regions
  vector<Interpolation> interpolation_; //!< Interpolation laws
  vector<double> energy_;        //!< Energies [eV] at which distributions
                                 //!< are tabulated
  vector<KMTable> distribution_; //!< Distribution at each energy
};

} // namespace openmc

#endif // OPENMC_SECONDARY_KALBACH_H
