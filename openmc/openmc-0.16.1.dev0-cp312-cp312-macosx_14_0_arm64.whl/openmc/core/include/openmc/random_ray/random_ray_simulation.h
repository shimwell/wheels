#ifndef OPENMC_RANDOM_RAY_SIMULATION_H
#define OPENMC_RANDOM_RAY_SIMULATION_H

#include "openmc/random_ray/flat_source_domain.h"
#include "openmc/random_ray/linear_source_domain.h"
#include "openmc/random_ray/ray_bank.h"

namespace openmc {

/*
 * The RandomRaySimulation class encompasses data and methods for running a
 * random ray simulation.
 */

class RandomRaySimulation {
public:
  //----------------------------------------------------------------------------
  // Constructors
  RandomRaySimulation();

  //----------------------------------------------------------------------------
  // Methods
  void apply_fixed_sources_and_mesh_domains();
  void prepare_fw_fixed_sources_adjoint();
  void prepare_local_fixed_sources_adjoint();
  void prepare_adjoint_simulation(bool from_forward);
  void simulate();
  void output_simulation_results();
  void instability_check(
    int64_t n_hits, double k_eff, double& avg_miss_rate) const;
  void print_results_random_ray(uint64_t total_geometric_intersections,
    double avg_miss_rate, int negroups, int64_t n_source_regions,
    int64_t n_external_source_regions, uint64_t avg_num_comms,
    double max_load_imbalance) const;
  void transport_sweep();
  void transport_sweep_decomp(RayBank& RB);

  //----------------------------------------------------------------------------
  // Accessors
  FlatSourceDomain* domain() const { return domain_.get(); }

private:
  //----------------------------------------------------------------------------
  // Data members

  // Contains all flat source region data
  unique_ptr<FlatSourceDomain> domain_;

  // Tracks the average FSR miss rate for analysis and reporting
  double avg_miss_rate_ {0.0};

  // Tracks the total number of geometric intersections by all rays for
  // reporting
  uint64_t total_geometric_intersections_ {0};

  // Number of energy groups
  int negroups_;

  // Average number of ray communications between rank per batch
  uint64_t avg_num_communication_rounds_ {0};

  // Tracks whether geometry-dependent one-time setup has already run for
  // this simulation object across forward/adjoint solves.
  bool geometry_setup_complete_ {false};

}; // class RandomRaySimulation

//============================================================================
//! Non-member functions
//============================================================================

void validate_random_ray_inputs();
void openmc_finalize_random_ray();

} // namespace openmc

#endif // OPENMC_RANDOM_RAY_SIMULATION_H
