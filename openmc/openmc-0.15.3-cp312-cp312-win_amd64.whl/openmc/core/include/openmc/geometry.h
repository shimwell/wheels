#ifndef OPENMC_GEOMETRY_H
#define OPENMC_GEOMETRY_H

#include <cmath>
#include <cstdint>
#include <unordered_map>
#include <vector>

#include "openmc/array.h"
#include "openmc/constants.h"
#include "openmc/random_ray/source_region.h" // For hash_combine
#include "openmc/vector.h"

namespace openmc {

class BoundaryInfo;
class GeometryState;

//==============================================================================
//! OverlapKey to store cell and universe data of a single overlap, along with
//! a functor for hashing an OverlapKey into an unordered_map.
//==============================================================================

struct OverlapKey {
  int universe_id;
  int cell1_id;
  int cell2_id;

  bool operator==(const OverlapKey& other) const
  {
    return universe_id == other.universe_id && cell1_id == other.cell1_id &&
           cell2_id == other.cell2_id;
  }
};

struct OverlapKeyHash {
  std::size_t operator()(const OverlapKey& k) const
  {
    size_t seed = 0;
    hash_combine(seed, k.universe_id);
    hash_combine(seed, k.cell1_id);
    hash_combine(seed, k.cell2_id);
    return seed;
  }
};

//==============================================================================
// Global variables
//==============================================================================

namespace model {

extern int root_universe;  //!< Index of root universe
extern int n_coord_levels; //!< Number of CSG coordinate levels

extern vector<int64_t> overlap_check_count;

// Overlap data structures get cleared every slice_data run
extern vector<OverlapKey> overlap_keys;
extern std::unordered_map<OverlapKey, int, OverlapKeyHash> overlap_key_index;

} // namespace model

//==============================================================================
//! Check two distances by coincidence tolerance
//==============================================================================

inline bool coincident(double d1, double d2)
{
  return std::abs(d1 - d2) < FP_COINCIDENT;
}

//==============================================================================
//! Check for overlapping cells at a particle's position.
//==============================================================================
int check_cell_overlap(GeometryState& p, bool error = true);

//==============================================================================
//! Get the cell instance for a particle at the specified universe level
//!
//! \param p A particle for which to compute the instance using
//!   its coordinates
//! \param level The level (zero indexed) of the geometry where the instance
//! should be computed. \return The instance of the cell at the specified level.
//==============================================================================

int cell_instance_at_level(const GeometryState& p, int level);

//==============================================================================
//! Locate a particle in the geometry tree and set its geometry data fields.
//!
//! \param p A particle to be located.  This function will populate the
//!   geometry-dependent data fields of the particle.
//! \return True if the particle's location could be found and ascribed to a
//!   valid geometry coordinate stack.
//==============================================================================
bool exhaustive_find_cell(GeometryState& p, bool verbose = false);

//==============================================================================
//! Locate a particle starting from its current coordinate level.
//==============================================================================
bool neighbor_list_find_cell(GeometryState& p, bool verbose = false);

//==============================================================================
//! Reconcile the current cell after a direction change near a surface.
//!
//! \param p A particle whose coordinate stack may need to be updated.
//==============================================================================

void reconcile_cell_after_collision(GeometryState& p);

//==============================================================================
//! Move a particle into a new lattice tile.
//==============================================================================

void cross_lattice(
  GeometryState& p, const BoundaryInfo& boundary, bool verbose = false);

//==============================================================================
//! Find the next boundary a particle will intersect.
//==============================================================================

BoundaryInfo distance_to_boundary(GeometryState& p);

} // namespace openmc

#endif // OPENMC_GEOMETRY_H
