#ifndef OPENMC_VERSION_H
#define OPENMC_VERSION_H

#include "openmc/array.h"

namespace openmc {

// OpenMC major, minor, and release numbers
// clang-format off
constexpr int VERSION_MAJOR {0};
constexpr int VERSION_MINOR {15};
constexpr int VERSION_RELEASE {3};
constexpr bool VERSION_DEV {true};
constexpr const char* VERSION_COMMIT_COUNT = "446";
constexpr const char* VERSION_COMMIT_HASH = "4534f07d9c72ede44ef852f9a24c488a4f34bb8a";
constexpr std::array<int, 3> VERSION {VERSION_MAJOR, VERSION_MINOR, VERSION_RELEASE};
// clang-format on

} // namespace openmc

#endif // OPENMC_VERSION_H
