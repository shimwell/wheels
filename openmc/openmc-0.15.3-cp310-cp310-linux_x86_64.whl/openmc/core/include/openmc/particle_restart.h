#ifndef OPENMC_PARTICLE_RESTART_H
#define OPENMC_PARTICLE_RESTART_H

namespace openmc {

void run_particle_restart();

} // namespace openmc

#endif // OPENMC_PARTICLE_RESTART_H
